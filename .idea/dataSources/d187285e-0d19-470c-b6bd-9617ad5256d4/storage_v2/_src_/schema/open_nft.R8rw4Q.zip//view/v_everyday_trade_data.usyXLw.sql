create definer = root@`%` view v_everyday_trade_data as
select concat(convert(`a`.`everyday` using utf8), `a`.`biz_mode`) AS `id`,
       str_to_date(`a`.`everyday`, '%Y-%m-%d %H:%i:%s')           AS `everyday`,
       `a`.`biz_mode`                                             AS `biz_mode`,
       `a`.`success_amount`                                       AS `success_amount`,
       `a`.`success_count`                                        AS `success_count`
from (select date_format(`open_nft`.`pay_order`.`create_time`, '%Y-%m-%d')             AS `everyday`,
             `open_nft`.`pay_order`.`biz_mode`                                         AS `biz_mode`,
             round(sum((case
                            when (`open_nft`.`pay_order`.`state` = '2') then `open_nft`.`pay_order`.`amount`
                            else 0 end)), 2)                                           AS `success_amount`,
             sum((case when (`open_nft`.`pay_order`.`state` = '2') then 1 else 0 end)) AS `success_count`
      from `open_nft`.`pay_order`
      group by `open_nft`.`pay_order`.`biz_mode`, date_format(`open_nft`.`pay_order`.`create_time`, '%Y-%m-%d')) `a`;

