create
    definer = root@`%` function get_time() returns int deterministic
    RETURN TIME(FROM_UNIXTIME(RAND() * (1356892200 - 1325356200) + 1325356200));

