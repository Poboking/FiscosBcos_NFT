create
    definer = root@`%` function get_varchar(in_length varchar(500)) returns varchar(500) deterministic
    RETURN SUBSTRING(MD5(RAND()) FROM 1 FOR in_length);

