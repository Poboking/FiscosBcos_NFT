create
    definer = root@`%` function get_datetime() returns varchar(30) deterministic
    RETURN FROM_UNIXTIME(ROUND(RAND() * (1356892200 - 1325356200)) + 1325356200);

