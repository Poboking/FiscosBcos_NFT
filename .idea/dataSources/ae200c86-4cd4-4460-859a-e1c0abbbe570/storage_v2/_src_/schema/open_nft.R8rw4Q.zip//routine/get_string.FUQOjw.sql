create
    definer = root@`%` function get_string(in_strlen int, in_col_name varchar(100)) returns varchar(500) deterministic
BEGIN
DECLARE is_id_column INT DEFAULT 0;
IF (LOCATE('id', in_col_name) > 0) THEN
    SET is_id_column = 1;
END IF;

set @var:='';
IF (in_strlen > 500) THEN SET in_strlen = 500; END IF;
while(in_strlen > 0) do
    IF (is_id_column = 1) THEN
        set @var := concat(@var, FLOOR(RAND() * 10)); -- 仅使用数字
    ELSE
        set @var := concat(@var, IFNULL(ELT(1 + FLOOR(RAND() * 53), 'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',' ','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'),'Kedar'));
    END IF;
    set in_strlen := in_strlen - 1;
end while;
RETURN @var;
END;

