create
    definer = root@`%` function get_int() returns int deterministic
    RETURN floor(rand()*10000000);

