create
    definer = root@`%` function get_date() returns varchar(10) deterministic
    RETURN DATE(FROM_UNIXTIME(RAND() * (1356892200 - 1325356200) + 1325356200));

