create
    definer = root@`%` function get_tinyint() returns int deterministic
    RETURN floor(rand()*100);

