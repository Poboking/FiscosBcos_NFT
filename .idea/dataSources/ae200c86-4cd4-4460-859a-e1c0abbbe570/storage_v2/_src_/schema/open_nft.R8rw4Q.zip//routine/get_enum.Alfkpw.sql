create
    definer = root@`%` function get_enum(col_type varchar(100)) returns varchar(100) deterministic
    RETURN if((@var:=ceil(rand()*10)) > (length(col_type)-length(replace(col_type,',',''))+1),(length(col_type)-length(replace(col_type,',',''))+1),@var);

