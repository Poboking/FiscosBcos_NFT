create
    definer = root@`%` function get_float(in_precision int, in_scale int) returns varchar(100) deterministic
    RETURN round(rand()*pow(10,(in_precision-in_scale)),in_scale);

